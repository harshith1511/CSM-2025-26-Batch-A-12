
import { YOLOVersion, ModelMetrics } from './types';

export const MODEL_BENCHMARKS: ModelMetrics[] = [
  {
    version: YOLOVersion.V8,
    map: 0.53,
    precision: 0.82,
    recall: 0.79,
    fps: 42,
    params: '3.2M',
    advantages: ['Lightweight', 'Fast inference', 'Good general detection']
  },
  {
    version: YOLOVersion.V9,
    map: 0.58,
    precision: 0.85,
    recall: 0.81,
    fps: 38,
    params: '4.1M',
    advantages: ['Cross-attention modules', 'Better occlusion handling']
  },
  {
    version: YOLOVersion.V10,
    map: 0.62,
    precision: 0.88,
    recall: 0.84,
    fps: 40,
    params: '4.8M',
    advantages: ['Multi-scale feature fusion', 'Dynamic receptive fields']
  },
  {
    version: YOLOVersion.V11,
    map: 0.65,
    precision: 0.91,
    recall: 0.87,
    fps: 45,
    params: '5.2M',
    advantages: ['Temporal-aware transformer', 'Sequence consistency']
  },
  {
    version: YOLOVersion.V12,
    map: 0.69,
    precision: 0.94,
    recall: 0.91,
    fps: 48,
    params: '5.9M',
    advantages: ['Advanced spatial-temporal fusion', 'Extreme low-light optimization']
  }
];

export const COLORS = {
  primary: '#3b82f6', // blue-500
  secondary: '#10b981', // emerald-500
  accent: '#f59e0b', // amber-500
  danger: '#ef4444', // red-500
  bg: '#000000',
  card: '#111111',
  border: '#222222'
};
