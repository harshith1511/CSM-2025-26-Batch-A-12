
import React from 'react';
import { Link, useLocation } from 'react-router-dom';

interface LayoutProps {
  children: React.ReactNode;
  user: { username: string } | null;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout }) => {
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'Overview', icon: 'fa-house' },
    { path: '/dashboard', label: 'Detection Engine', icon: 'fa-microchip' },
    { path: '/comparison', label: 'Performance Analysis', icon: 'fa-chart-line' },
    { path: '/research', label: 'Project Documentation', icon: 'fa-file-lines' },
    { path: '/about', label: 'Methodology', icon: 'fa-book' },
  ];

  return (
    <div className="flex min-h-screen bg-black text-gray-200">
      {/* Sidebar */}
      <aside className="w-64 border-r border-gray-800 bg-zinc-950 flex flex-col fixed inset-y-0">
        <div className="p-6 border-b border-gray-800 flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <i className="fa-solid fa-person-walking text-white text-xl"></i>
          </div>
          <div>
            <h1 className="font-bold text-sm tracking-tight leading-none">PED-DET</h1>
            <p className="text-[10px] text-gray-500 uppercase tracking-widest mt-1">Autonomous Systems</p>
          </div>
        </div>

        <nav className="flex-1 py-6 px-3 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                location.pathname === item.path
                  ? 'bg-blue-600/10 text-blue-500 border border-blue-600/20'
                  : 'text-gray-400 hover:text-white hover:bg-zinc-900'
              }`}
            >
              <i className={`fa-solid ${item.icon} w-5 text-center`}></i>
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-800 bg-zinc-900/50">
          {user ? (
            <div className="space-y-3">
              <div className="flex items-center gap-3 px-2">
                <div className="w-8 h-8 rounded-full bg-zinc-700 flex items-center justify-center text-xs font-bold uppercase">
                  {user.username.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{user.username}</p>
                  <p className="text-xs text-green-500 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                    Verified Session
                  </p>
                </div>
              </div>
              <button
                onClick={onLogout}
                className="w-full py-2 px-4 rounded-lg bg-zinc-800 hover:bg-red-950/30 hover:text-red-500 transition-colors text-xs font-medium border border-zinc-700 flex items-center justify-center gap-2"
              >
                <i className="fa-solid fa-arrow-right-from-bracket"></i>
                Sign Out
              </button>
            </div>
          ) : (
            <Link
              to="/login"
              className="w-full py-2.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors text-sm font-medium flex items-center justify-center gap-2"
            >
              <i className="fa-solid fa-lock"></i>
              Access Terminal
            </Link>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="ml-64 flex-1 flex flex-col">
        <header className="h-16 border-b border-gray-800 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-50 flex items-center justify-between px-8">
          <div className="flex items-center gap-4">
             <div className="flex items-center gap-2 text-xs text-gray-500">
               <span className="px-2 py-0.5 rounded bg-zinc-800 text-gray-400 border border-zinc-700">v2.5.4</span>
               <span className="text-zinc-600">|</span>
               <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500"></span> System Active</span>
             </div>
          </div>
          <div className="flex items-center gap-6">
            <button className="text-gray-400 hover:text-white transition-colors"><i className="fa-solid fa-magnifying-glass"></i></button>
            <button className="text-gray-400 hover:text-white transition-colors relative">
                <i className="fa-solid fa-bell"></i>
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-blue-500 rounded-full"></span>
            </button>
          </div>
        </header>

        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
