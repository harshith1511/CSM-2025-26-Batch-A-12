
import React, { useEffect, useRef } from 'react';
import { BoundingBox } from '../types';

interface DetectionCanvasProps {
  imageSrc: string;
  boxes: BoundingBox[];
}

const DetectionCanvas: React.FC<DetectionCanvasProps> = ({ imageSrc, boxes }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.src = imageSrc;
    img.onload = () => {
      // Calculate aspect ratio fit
      const parentWidth = container.clientWidth;
      const parentHeight = container.clientHeight || 500;
      const imgRatio = img.width / img.height;
      const parentRatio = parentWidth / parentHeight;

      let drawWidth, drawHeight;
      if (imgRatio > parentRatio) {
        drawWidth = parentWidth;
        drawHeight = parentWidth / imgRatio;
      } else {
        drawHeight = parentHeight;
        drawWidth = parentHeight * imgRatio;
      }

      canvas.width = drawWidth;
      canvas.height = drawHeight;

      // Draw Image
      ctx.drawImage(img, 0, 0, drawWidth, drawHeight);

      // Draw Boxes
      boxes.forEach(box => {
        const x = (box.x1 / 1000) * drawWidth;
        const y = (box.y1 / 1000) * drawHeight;
        const width = ((box.x2 - box.x1) / 1000) * drawWidth;
        const height = ((box.y2 - box.y1) / 1000) * drawHeight;

        // Choose color based on occlusion
        let color = '#3b82f6'; // blue
        if (box.occlusion === 'partial') color = '#f59e0b'; // amber
        if (box.occlusion === 'heavy') color = '#ef4444'; // red

        ctx.strokeStyle = color;
        ctx.lineWidth = 2.5;
        ctx.strokeRect(x, y, width, height);

        // Label Background
        ctx.fillStyle = color;
        const label = `${box.label} ${(box.confidence * 100).toFixed(0)}%`;
        ctx.font = 'bold 12px Inter';
        const textMetrics = ctx.measureText(label);
        ctx.fillRect(x, y - 20, textMetrics.width + 10, 20);

        // Label Text
        ctx.fillStyle = '#fff';
        ctx.fillText(label, x + 5, y - 5);
        
        // Corner indicators for flair
        ctx.beginPath();
        ctx.moveTo(x, y + 10); ctx.lineTo(x, y); ctx.lineTo(x + 10, y);
        ctx.stroke();
      });
    };
  }, [imageSrc, boxes]);

  return (
    <div ref={containerRef} className="w-full h-full min-h-[400px] flex items-center justify-center bg-zinc-900 rounded-2xl overflow-hidden border border-zinc-800 shadow-2xl relative">
      <canvas ref={canvasRef} className="max-w-full h-auto" />
      {boxes.length === 0 && (
        <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-500 gap-4">
          <i className="fa-solid fa-eye-slash text-4xl opacity-20"></i>
          <p className="text-sm font-medium uppercase tracking-widest opacity-40">No Input Data Detected</p>
        </div>
      )}
    </div>
  );
};

export default DetectionCanvas;
