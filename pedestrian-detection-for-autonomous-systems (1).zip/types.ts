
export enum YOLOVersion {
  V8 = 'YOLOv8',
  V9 = 'YOLOv9',
  V10 = 'YOLOv10',
  V11 = 'YOLOv11',
  V12 = 'YOLOv12'
}

export interface BoundingBox {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  label: string;
  confidence: number;
  occlusion?: 'none' | 'partial' | 'heavy';
}

export interface DetectionResult {
  version: YOLOVersion;
  detections: BoundingBox[];
  inferenceTime: number; // ms
  fps: number;
  timestamp: number;
}

export interface ModelMetrics {
  version: YOLOVersion;
  map: number;
  precision: number;
  recall: number;
  fps: number;
  params: string;
  advantages: string[];
}

export interface UserSession {
  username: string;
  isLoggedIn: boolean;
}
