
import { GoogleGenAI, Type } from "@google/genai";
import { BoundingBox, YOLOVersion } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const detectPedestrians = async (
  base64Image: string,
  model: YOLOVersion
): Promise<BoundingBox[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          parts: [
            {
              inlineData: {
                data: base64Image.split(',')[1],
                mimeType: "image/jpeg"
              }
            },
            {
              text: `Act as a pedestrian detection system using ${model} architecture. Identify all pedestrians in this image. 
              Return a JSON array of objects. Each object must have:
              "x1", "y1", "x2", "y2" (coordinates normalized 0-1000), "label" (always "pedestrian"), "confidence" (float 0-1), and "occlusion" ("none", "partial", "heavy").
              
              Note on Model Simulation:
              - If ${model} is YOLOv8, omit some occluded or small pedestrians.
              - If ${model} is YOLOv9-v12, be more precise and include occluded ones.
              Only return the JSON array.`
            }
          ]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              x1: { type: Type.NUMBER },
              y1: { type: Type.NUMBER },
              x2: { type: Type.NUMBER },
              y2: { type: Type.NUMBER },
              label: { type: Type.STRING },
              confidence: { type: Type.NUMBER },
              occlusion: { type: Type.STRING }
            },
            required: ["x1", "y1", "x2", "y2", "label", "confidence"]
          }
        }
      }
    });

    const result = JSON.parse(response.text);
    return result;
  } catch (error) {
    console.error("Gemini Detection Error:", error);
    return [];
  }
};

export const getAIAnalysis = async (
  metrics: string,
  context: string
): Promise<string> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following pedestrian detection performance metrics in the context of autonomous systems.
    
    Metrics: ${metrics}
    Context: ${context}
    
    Provide a concise technical summary of why the proposed YOLO models outperform the baseline YOLOv8, focusing on occlusion and low-light reliability. Format as markdown.`
  });
  return response.text;
};
