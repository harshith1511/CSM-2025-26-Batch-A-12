
import React, { useState, useRef } from 'react';
import { YOLOVersion, BoundingBox } from '../types';
import { detectPedestrians } from '../services/geminiService';
import DetectionCanvas from '../components/DetectionCanvas';
import { MODEL_BENCHMARKS } from '../constants';

const DashboardPage: React.FC = () => {
  const [selectedModel, setSelectedModel] = useState<YOLOVersion>(YOLOVersion.V12);
  const [image, setImage] = useState<string | null>(null);
  const [isDetecting, setIsDetecting] = useState(false);
  const [results, setResults] = useState<BoundingBox[]>([]);
  const [stats, setStats] = useState<{ fps: number; time: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
        setResults([]);
        setStats(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDetect = async () => {
    if (!image) return;
    setIsDetecting(true);
    const start = performance.now();
    
    const detections = await detectPedestrians(image, selectedModel);
    
    const end = performance.now();
    setResults(detections);
    const time = Math.round(end - start);
    // Simulate model-specific FPS variations based on actual model benchmarks
    const benchmark = MODEL_BENCHMARKS.find(m => m.version === selectedModel);
    setStats({ 
      time, 
      fps: benchmark ? benchmark.fps + (Math.random() * 5 - 2.5) : 30 
    });
    setIsDetecting(false);
  };

  const currentBenchmark = MODEL_BENCHMARKS.find(m => m.version === selectedModel);

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header Info */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight">Detection Terminal</h2>
          <p className="text-gray-400 mt-2 max-w-2xl">
            Upload environmental data or stream footage to perform real-time pedestrian extraction using advanced spatial-temporal YOLO architectures.
          </p>
        </div>
        
        <div className="flex items-center gap-3">
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value as YOLOVersion)}
              className="bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
            >
              {Object.values(YOLOVersion).map((v) => (
                <option key={v} value={v}>{v}</option>
              ))}
            </select>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-6 py-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-sm font-semibold transition-all flex items-center gap-2 border border-zinc-700"
            >
              <i className="fa-solid fa-upload"></i>
              Import Frame
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              className="hidden"
              accept="image/*"
            />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Detection Area */}
        <div className="lg:col-span-8 space-y-6">
          <div className="relative group">
            <DetectionCanvas imageSrc={image || 'https://picsum.photos/1200/800?grayscale'} boxes={results} />
            
            {isDetecting && (
              <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center z-10 rounded-2xl">
                <div className="w-16 h-16 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin mb-4"></div>
                <p className="text-sm font-mono text-blue-400 tracking-widest animate-pulse">EXTRACTING FEATURES...</p>
              </div>
            )}

            {!results.length && image && !isDetecting && (
                <button
                    onClick={handleDetect}
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-full font-bold shadow-2xl flex items-center gap-3 transition-transform hover:scale-105 active:scale-95"
                >
                    <i className="fa-solid fa-play"></i>
                    Initialize Inference
                </button>
            )}
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800">
                <p className="text-[10px] text-gray-500 uppercase tracking-widest font-bold mb-1">Inference Time</p>
                <p className="text-2xl font-mono font-bold text-white">{stats ? `${stats.time}ms` : '--'}</p>
            </div>
            <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800">
                <p className="text-[10px] text-gray-500 uppercase tracking-widest font-bold mb-1">FPS Frequency</p>
                <p className="text-2xl font-mono font-bold text-emerald-500">{stats ? `${stats.fps.toFixed(1)}` : '--'}</p>
            </div>
            <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800">
                <p className="text-[10px] text-gray-500 uppercase tracking-widest font-bold mb-1">Detections</p>
                <p className="text-2xl font-mono font-bold text-blue-500">{results.length}</p>
            </div>
          </div>
        </div>

        {/* Right: Insights & Controls */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 space-y-6">
            <h3 className="font-bold flex items-center gap-2">
              <i className="fa-solid fa-sliders text-blue-500"></i>
              Model Parameters
            </h3>
            
            <div className="space-y-4">
                <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-500">Selected Architecture</span>
                    <span className="text-blue-400 font-mono">{selectedModel}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-500">Trainable Weights</span>
                    <span className="text-white font-mono">{currentBenchmark?.params}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-500">Resolution Mode</span>
                    <span className="text-white font-mono">640x640 FP16</span>
                </div>
                <div className="h-px bg-zinc-800"></div>
                <div>
                    <p className="text-[10px] text-gray-500 uppercase tracking-widest font-bold mb-3">Core Enhancements</p>
                    <div className="space-y-2">
                        {currentBenchmark?.advantages.map((adv, i) => (
                            <div key={i} className="flex items-center gap-2 text-xs text-gray-300">
                                <i className="fa-solid fa-circle-check text-emerald-500"></i>
                                {adv}
                            </div>
                        ))}
                    </div>
                </div>
            </div>
          </div>

          <div className="bg-blue-600/5 border border-blue-500/20 rounded-2xl p-6 space-y-4">
             <h3 className="text-blue-400 font-bold text-sm uppercase tracking-wider flex items-center gap-2">
                <i className="fa-solid fa-circle-info"></i>
                Environment Feedback
             </h3>
             <p className="text-xs text-gray-400 leading-relaxed italic">
                "{selectedModel} is currently optimized for high-density urban environments. Advanced multi-scale feature fusion allows for superior tracking of small pedestrians at distances exceeding 100 meters."
             </p>
             <div className="pt-2">
                <div className="w-full bg-zinc-800 h-1 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500" style={{ width: `${(currentBenchmark?.map || 0) * 100}%` }}></div>
                </div>
                <div className="flex justify-between mt-2">
                    <span className="text-[10px] text-gray-600 font-bold uppercase">Confidence Score Index</span>
                    <span className="text-[10px] text-blue-500 font-bold">{Math.round((currentBenchmark?.map || 0) * 100)}% mAP</span>
                </div>
             </div>
          </div>

          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
            <h3 className="font-bold mb-4 text-sm flex items-center gap-2">
                <i className="fa-solid fa-list-check text-amber-500"></i>
                Detection Logs
            </h3>
            <div className="max-h-[200px] overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                {results.length > 0 ? results.map((res, i) => (
                    <div key={i} className="flex items-center justify-between p-2 rounded bg-zinc-800/50 border border-zinc-800 text-[11px]">
                        <span className="text-gray-400 font-mono">#{i.toString().padStart(3, '0')}</span>
                        <span className="text-gray-200 uppercase font-bold">Pedestrian</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${res.occlusion === 'none' ? 'text-emerald-500' : res.occlusion === 'partial' ? 'text-amber-500' : 'text-red-500'}`}>
                            {res.occlusion}
                        </span>
                        <span className="text-blue-500 font-mono">{(res.confidence * 100).toFixed(1)}%</span>
                    </div>
                )) : (
                    <div className="text-center py-8 text-gray-600 italic text-xs">Waiting for input...</div>
                )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
