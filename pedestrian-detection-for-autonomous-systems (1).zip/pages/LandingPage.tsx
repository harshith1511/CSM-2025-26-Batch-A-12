
import React from 'react';

const LandingPage: React.FC = () => {
  return (
    <div className="max-w-5xl mx-auto space-y-16 py-8">
      {/* Hero Section */}
      <section className="text-center space-y-8">
        <div className="inline-block px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-500 text-xs font-bold uppercase tracking-widest mb-4">
          Advanced Research Project 2026
        </div>
        <h1 className="text-5xl md:text-6xl font-extrabold text-white leading-tight tracking-tighter">
          Deep Learning for <br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-emerald-500">Autonomous Pedestrian Detection</span>
        </h1>
        <p className="text-lg text-gray-400 max-w-3xl mx-auto leading-relaxed">
          Pioneering enhanced YOLO architectures to solve critical challenges in modern autonomous systems: occlusion, scale variance, and low-light environments.
        </p>
        <div className="flex justify-center gap-4">
          <a href="#/dashboard" className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-bold transition-all shadow-xl shadow-blue-900/20">
            Launch Detection Terminal
          </a>
          <a href="#/about" className="px-8 py-4 bg-zinc-800 hover:bg-zinc-700 text-white rounded-2xl font-bold border border-zinc-700 transition-all">
            Read Whitepaper
          </a>
        </div>
      </section>

      {/* Grid Features */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="p-8 bg-zinc-900 rounded-3xl border border-zinc-800 hover:border-blue-500/30 transition-colors">
          <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-500 text-2xl mb-6">
            <i className="fa-solid fa-eye"></i>
          </div>
          <h3 className="text-xl font-bold mb-4">Occlusion Mastery</h3>
          <p className="text-gray-400 text-sm leading-relaxed">
            Integrating cross-attention modules (YOLOv9) to maintain high tracking confidence even when pedestrians are partially obscured by urban infrastructure.
          </p>
        </div>
        <div className="p-8 bg-zinc-900 rounded-3xl border border-zinc-800 hover:border-emerald-500/30 transition-colors">
          <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500 text-2xl mb-6">
            <i className="fa-solid fa-expand"></i>
          </div>
          <h3 className="text-xl font-bold mb-4">Scale Adaptability</h3>
          <p className="text-gray-400 text-sm leading-relaxed">
            Multi-scale feature fusion (YOLOv10) enables the system to detect distant pedestrians as small as 20px with the same precision as near-field targets.
          </p>
        </div>
        <div className="p-8 bg-zinc-900 rounded-3xl border border-zinc-800 hover:border-amber-500/30 transition-colors">
          <div className="w-12 h-12 bg-amber-500/10 rounded-2xl flex items-center justify-center text-amber-500 text-2xl mb-6">
            <i className="fa-solid fa-moon"></i>
          </div>
          <h3 className="text-xl font-bold mb-4">Low-Light Robustness</h3>
          <p className="text-gray-400 text-sm leading-relaxed">
            Proprietary YOLOv12 architecture specifically tuned for SNR-challenged environments, ensuring 24/7 reliability for autonomous navigation.
          </p>
        </div>
      </section>

      {/* Abstract Content */}
      <section className="bg-zinc-950 p-12 rounded-3xl border border-zinc-800 space-y-8">
        <h2 className="text-3xl font-bold text-white">Technical Abstract</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="space-y-4 text-gray-400 leading-relaxed text-sm">
            <p>
              Pedestrian detection is a critical component in autonomous systems, ensuring safe navigation and collision prevention. While YOLOv8 offers improved detection speed and accuracy compared to its predecessors, it still faces challenges in detecting partially occluded, small-scale, and densely grouped pedestrians.
            </p>
            <p>
              To address these issues, we propose four enhanced models—YOLOv9, YOLOv10, YOLOv11 and YOLOv12—each integrating architectural advancements such as adaptive attention mechanisms, multi-scale feature fusion, and temporal context modeling.
            </p>
          </div>
          <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
             <h4 className="text-white font-bold mb-4 text-xs uppercase tracking-widest text-blue-500">Key Performance Indicators</h4>
             <div className="space-y-4">
                {[
                  { label: 'mAP@0.5 Improvement', value: '+16%' },
                  { label: 'Latency Reduction', value: '-12ms' },
                  { label: 'Occlusion Recovery', value: '94%' },
                  { label: 'Low-Light Precision', value: '88%' }
                ].map((stat, i) => (
                  <div key={i} className="flex justify-between items-center">
                    <span className="text-gray-400 text-sm">{stat.label}</span>
                    <span className="text-white font-bold font-mono">{stat.value}</span>
                  </div>
                ))}
             </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
