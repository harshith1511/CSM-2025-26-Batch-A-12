
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area, Legend } from 'recharts';
import { MODEL_BENCHMARKS, COLORS } from '../constants';

const ComparisonPage: React.FC = () => {
  const chartData = MODEL_BENCHMARKS.map(m => ({
    name: m.version,
    mAP: (m.map * 100).toFixed(1),
    Precision: (m.precision * 100).toFixed(1),
    Recall: (m.recall * 100).toFixed(1),
    FPS: m.fps
  }));

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-white tracking-tight">System Performance Benchmarking</h2>
        <p className="text-gray-400 mt-2 max-w-2xl">
          Comparative analysis of the proposed models (YOLOv9-v12) against the baseline YOLOv8 on the CityPersons dataset.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Detection Accuracy Chart */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 space-y-6 shadow-xl">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold">Detection Accuracy (mAP@0.5)</h3>
            <span className="text-xs bg-emerald-500/10 text-emerald-500 px-3 py-1 rounded-full font-bold uppercase tracking-widest border border-emerald-500/20">Higher is Better</span>
          </div>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                <XAxis dataKey="name" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#666" fontSize={12} tickLine={false} axisLine={false} domain={[0, 100]} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#111', border: '1px solid #333', borderRadius: '12px' }}
                  itemStyle={{ color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="mAP" fill={COLORS.primary} radius={[6, 6, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Real-time Performance Chart */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 space-y-6 shadow-xl">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold">Inference Speed (FPS)</h3>
            <span className="text-xs bg-blue-500/10 text-blue-500 px-3 py-1 rounded-full font-bold uppercase tracking-widest border border-blue-500/20">Real-time > 30 FPS</span>
          </div>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorFps" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={COLORS.secondary} stopOpacity={0.3}/>
                    <stop offset="95%" stopColor={COLORS.secondary} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                <XAxis dataKey="name" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#111', border: '1px solid #333', borderRadius: '12px' }}
                  itemStyle={{ color: '#fff', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="FPS" stroke={COLORS.secondary} strokeWidth={3} fillOpacity={1} fill="url(#colorFps)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Precision vs Recall Scatter/Line */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 space-y-6 shadow-xl lg:col-span-2">
            <h3 className="text-lg font-bold">Precision-Recall Reliability Matrix</h3>
            <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                        <XAxis dataKey="name" stroke="#666" />
                        <YAxis stroke="#666" domain={[70, 100]} />
                        <Tooltip contentStyle={{ backgroundColor: '#111', border: '1px solid #333', borderRadius: '12px' }} />
                        <Legend verticalAlign="top" height={36} iconType="circle" />
                        <Line type="monotone" dataKey="Precision" stroke={COLORS.accent} strokeWidth={4} dot={{ r: 6, fill: COLORS.accent }} activeDot={{ r: 8 }} />
                        <Line type="monotone" dataKey="Recall" stroke={COLORS.primary} strokeWidth={4} dot={{ r: 6, fill: COLORS.primary }} activeDot={{ r: 8 }} />
                    </LineChart>
                </ResponsiveContainer>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {MODEL_BENCHMARKS.map((m) => (
          <div key={m.version} className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 transition-transform hover:-translate-y-1">
            <p className="text-blue-500 font-bold mb-2">{m.version}</p>
            <div className="space-y-4">
               <div>
                  <p className="text-[10px] text-gray-500 uppercase font-bold">Accuracy</p>
                  <p className="text-xl font-mono text-white">{(m.map * 100).toFixed(0)}%</p>
               </div>
               <div>
                  <p className="text-[10px] text-gray-500 uppercase font-bold">Stability</p>
                  <p className="text-xl font-mono text-white">{(m.precision * 100).toFixed(0)}%</p>
               </div>
               <div>
                  <p className="text-[10px] text-gray-500 uppercase font-bold">Latency</p>
                  <p className="text-xl font-mono text-emerald-500">{m.fps} FPS</p>
               </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ComparisonPage;
