
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import LandingPage from './pages/LandingPage';
import DashboardPage from './pages/DashboardPage';
import ComparisonPage from './pages/ComparisonPage';
import ResearchPage from './pages/ResearchPage';
import Login from './pages/Login';
import { UserSession } from './types';

const App: React.FC = () => {
  const [user, setUser] = useState<UserSession | null>(null);

  useEffect(() => {
    // Check local storage for persistent session
    const savedUser = localStorage.getItem('user_session');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogin = (username: string) => {
    const newUser = { username, isLoggedIn: true };
    setUser(newUser);
    localStorage.setItem('user_session', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user_session');
  };

  return (
    <Router>
      <Layout user={user} onLogout={handleLogout}>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/about" element={<LandingPage />} />
          <Route path="/dashboard" element={
            user ? <DashboardPage /> : <Navigate to="/login" replace />
          } />
          <Route path="/comparison" element={
            user ? <ComparisonPage /> : <Navigate to="/login" replace />
          } />
          <Route path="/research" element={
            user ? <ResearchPage /> : <Navigate to="/login" replace />
          } />
          <Route path="/login" element={<Login onLogin={handleLogin} />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;
